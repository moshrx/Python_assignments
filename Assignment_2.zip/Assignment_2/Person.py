class Person:
    def __init__(self, name, age, gender):
        self.name = name
        self.__age = age
        self.gender = gender
    
    def say_hello(self):
        return "Hi my name is ", self.name
    
    def get_age(self):
        return self.__age
    
    def is_adult(self):
        if self.__age >= 18:
            return True
        else:
            return False
        
person1 = Person("Mohammed", 22, "M")
print(person1.say_hello())
if person1.is_adult():
    print("yes")
else:
    print("no")

#Student class

class Student(Person):
    def __init__(self, name, age, gender, student_id, course):
        super().__init__(name, age, gender)
        self.id = student_id
        self.course = course
    
    def student_details(self):
        print("Name: ", self.name, "Age: ",self.get_age(), "Sex: ", self.gender, "student ID: ", self.id, "Course: ", self.course)

person2 = Student("Mohd", 20, "M", 1232234, "FSDM")
person2.student_details()

#Teacher class
class Teacher(Person):
    def __init__(self, name, age, gender, teacher_id, subject):
        super().__init__(name, age, gender)
        self.id = teacher_id
        self.subject = subject
    def get_age(self):
        return super().get_age()
    
    def say_hello(self):
        return "Name: ", self.name, "Subject: ", self.subject

person3 = Teacher("Professor", 55, "F", 4889945, "Python")
print(person3.say_hello())

person1.get_age()