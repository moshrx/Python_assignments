class Vehicle():
    def __init__(self):
        pass
    
    def name_of_vehicle(self, name):
        return "Vehicle name: ", name
    
    def max_speed(self, speed):
        return "max speed: ", speed

    def average_of_vehicle(self, avg):
        return "Average ", avg

class Child_vehicle(Vehicle):
    def seating_capacity(self, seat):
        return "Seating Capacity: ", seat

Honda = Vehicle()
print(Honda.name_of_vehicle("Honda"))
print(Honda.max_speed(100))
print(Honda.average_of_vehicle(16))

new_obj = Child_vehicle()
print(new_obj.seating_capacity(5))